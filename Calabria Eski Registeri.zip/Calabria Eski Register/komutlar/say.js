const Discord = require("discord.js");
const ayarlar = require('../ayarlar.json')
const mapping = {
  " ": "   ",
   "0": "<a:kabus000:905848123107205181>",
  "1": "<a:kabus111:890593910836047882>",
  "2": "<a:kabus222:890594001554645032>",
  "3": "<a:kabus333:890594167829438469>",
  "4": "<a:kabus444:890594077219905547>",
  "5": "<a:kabus555:890594038128979978>",
  "6": "<a:kabus666:890594105317535765>",
  "7": "<a:kabus777:890593971003351041>",
  "8": "<a:kabus888:890593940846288926>",
  "9": "<a:kabus999:890594140277067797>",
  "?": "❔",
  "#": "#️⃣",
  "*": "*️⃣"
};

let tags = ayarlar.tag;
"abcdefghijklmnopqr".split("").forEach(c => {
  mapping[c] = mapping[c.toUpperCase()] = `:regional_indicator_${c}:`;
});
exports.run = function(client, message, args) {
if(!['914104712809295883'].some(role => message.member.roles.cache.get(role)) && !message.member.hasPermission('ADMINISTRATOR')) 
return message.reply('Bu Komutu Kullanmak İçin Yetkiniz Bulunmamakta.').then(x => x.delete({timeout: 5000}));
  let selam = message.guild.members.cache.filter(
    m => m.user.presence.status === "offline"
  ).size;
  let offlinee = `${selam}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");
  let canım = message.guild.memberCount;
  let sunucu = `${canım}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");
  let ben = message.guild.members.cache.filter(
    m => !m.user.bot && m.user.presence.status !== "online"
  ).size;
  let onlinee = `${ben}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");

  let bacınım = message.guild.members.cache.filter(m =>
    m.user.username.includes(tags)
  ).size;
  let tagg = `${bacınım}`
      .split("")
      .map(c => mapping[c] || c)
      .join("");
  
  let legacy = message.guild.members.cache.filter(
    m => m.user.presence.status === "idle"
  ).size;
  let idlee = `${legacy}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");

  let burdanKendimeSelam = message.guild.members.cache.filter(
    m => m.user.presence.status === "dnd"
  ).size;
  let dndd = `${burdanKendimeSelam}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");

  const CuguliyiSeverim = message.guild.channels.cache
    .filter(channel => channel.type == "voice")
    .map(channel => channel.members.size)
    .reduce((a, b) => a + b);
  let sess = `${CuguliyiSeverim}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");

  const boyum158 = message.guild.roles.cache.get("914104712796717078").members.size;
  let kizz = `${boyum158}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");

  const Hayırsızlar = message.guild.roles.cache.get("918197054445088858")
    .members.size;
  let erkekk = `${Hayırsızlar}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");

  const boost = message.guild.premiumSubscriptionCount
let boostt = `${boost}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");

  const kayitsiz = message.guild.roles.cache.get("917505926997630996")
    .members.size;
  let kayitsizz = `${kayitsiz}`
      .split("")
      .map(c => mapping[c] || c)
      .join(" ");
  
const legacyy = new Discord.MessageEmbed()
.setTitle(`Sunucu İstatikleri`)
.setDescription(`**Sunucuda Toplam ${sunucu} Kişi Var
Sunucumuzda Toplam ${kizz} Kadın Kullanıcı ve ${erkekk} Erkek Kullanıcı Var
Toplam ${offlinee} Offline Kişi Var
Toplam ${onlinee} Online Kişi Var
Boşta Toplam ${idlee} Kişi Var
Rahatsız Etmeyinde Toplam ${dndd} Kişi Var
Ses Kanallarından ${sess} Kişi Bulunuyor.
✭ - Tagını Alan ${tagg} Kişi Var.
Sunucuda Toplam ${boostt} Boost Bulunuyor
**`
    )
    .setColor("GREEN")
//yukardakindende bakabilirsin mevcut degiskenlere
  // ben norsunkine benzesin diye onlari koymadim
  
const sj = new Discord.MessageEmbed()
.setAuthor(`${client.user.username}`, client.user.avatarURL({ dynamic: true }))
.setColor("BLACK")
.setThumbnail(message.guild.iconURL({ dynamic: true }))
.setFooter("Komutu Kullanan Kişi: "+message.author.tag+"" , message.author.avatarURL({ dynamic: true }))
.setDescription(`
<a:vianamaviii:889866430487592960> Sunucumuzda toplam ${sunucu} üye bulunmakta.
<a:vianamaviii:889866430487592960> Sunucumuzda toplam ${erkekk} erkek  ${kizz} kız ve ${kayitsizz} kayıtsız üye bulunmakta. 
<a:vianamaviii:889866430487592960> Ses kanallarında toplam ${sess} üye bulunmakta.
<a:vianamaviii:889866430487592960> \`✰\` Tagını Alan ${tagg} Kişi Var.
<a:vianamaviii:889866430487592960> Sunucuda toplam ${boostt} boost bulunuyor.`)
message.channel.send(sj).then(x => x.delete({timeout: 12000}));
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["say"],
  permLevel: 0
};

exports.help = {
  name: "say",
  usage: "Sunucudaki Online Kişileri Sayar",
  description: "say"
};

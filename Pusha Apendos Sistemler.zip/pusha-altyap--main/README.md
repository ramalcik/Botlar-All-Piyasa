**la recep efsanesi adlı kişi pusha yavşağı daha altyapı kullanmayı bilmiyorsun sabit bi adın bile yok noname türeme oğlu türeme kimseye prim yok dio KLFDJSALŞKFDJAŞKLFJDSAŞLKJFDŞALSKFJADSKLŞFJSKLŞFDJAS** (bu arada altyapıları hiç bişisini çözmeyip direk kullanmış hatalarını çözer atarım git bi public yönetmeyi öğren aq)

**güncelleme : lan amk recep efsane türemesi gidip mercyin paylaştığı altyapıyı alıp benim diye kullanmayı iyi biliyorsun FDJSAKFDSHAFJKLDAHSFJKSHDJKLDHSAFJKDAS MAL AQ**

**recep efsanesi APLAMIN KULLANDIĞI PARDON ÇALDIĞI ALTYAPILAR 3-5 ALTYAPI ALIP EDİTLEYİP BENİM DİYE PAYLAŞMIŞ BENDE SİZLERE VERİYORUM KULLANIRSINIZ ;)**

**kullandığı sistemler aspendosda ve şimdiki marinoda kuıllanıyor**


[Passenger#0001](https://discord.com/users/798257622033367070) ile [Mêrcylary#0001](https://discord.com/users/411621794131476480) ulaşabilirsiniz :D

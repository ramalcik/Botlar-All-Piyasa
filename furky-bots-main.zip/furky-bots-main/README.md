# furky-bots
Eskiden kullandığım v12 botlarım. 

v12 desteği bittiği ve Discord ile eskisi kadar ilgilenmediğim için paylaşıyorum. 
Kullanacak arkadaşlara hayırlı olsun, iyi kodlamalar :)




# Nasıl kullanılır?
Botların tokenini girin ve kullanın, direk kullandığım botları yükledim ve hepsi hatasız çalışıyor.



# Botlar Hakkında Bilgilendirme
Guard'da Rol, Kanal, Sunucu, Sağ Tık gibi bilinen bir çok koruma mevcut.
Moderasyon kurulumlu, en çok işinize yarayacak olan şey bu olabilir.
Auth botu çok tokenli rol dağıtma botu, bu işinize yarayabilir.
Sync botu da kanalların yedeklerini alıyor.



Hata çıkması durumunda Furky#1234 bana ulaşabilirsiniz.

const discord = require('discord.js');
const client = new discord.Client();
const disbut = require('discord-buttons')(client);
const cfg = require("./config.json");

client.on("message", async (msg) => {
let prefix = cfg.Bot.Prefix.find((x) => msg.content.toLowerCase().startsWith(x));
if (msg.content !== ""+prefix+"button" && msg.content !== ""+prefix+"buttons") return; 
if(!cfg.Bot.Owners.includes(msg.author.id) && !msg.guild.owner.user.id.includes(msg.author.id)) return

let ÇK = new disbut.MessageButton()
     .setStyle('red')
     .setLabel('🎁 Çekiliş Katılımcısı')
     .setID('ÇK')
let EK = new disbut.MessageButton()
    .setStyle('gray')
    .setLabel('🎉 Etkinlik Katılımcısı')
    .setID('EK')



msg.channel.send(`
 Merhaba **Galaxy** Üyeleri

 Çekiliş Katılımcısı alarak Netflix , Spotify  ,Nitro  ve benzeri çekilişlere katılıp ödül sahibi olabilirsiniz.

 Aşağıda bulunan butonlardan Etkinlik Katılımcısı alarak konserlerimizden, oyunlarımızdan, ve etkinliklerimizden faydalanabilirsiniz.
`, {
        buttons: [EK, ÇK]
    })

})
client.on('clickButton', async (button) => {

    if (button.id === 'ÇK') {
        if (button.clicker.member.roles.cache.get(cfg.Roles.ÇK)) {
            await button.clicker.member.roles.remove(cfg.Roles.ÇK)
            await button.think(true);
            await button.reply.edit(" Çekiliş Katılımcısı rolü üzerinizden alındı.")
        } else {
            await button.clicker.member.roles.add(cfg.Roles.ÇK)
            await button.think(true);
            await button.reply.edit(" Çekiliş Katılımcısı rolü üzerinize verildi.")
        }
    }
    if (button.id === 'EK') {
        if (button.clicker.member.roles.cache.get(cfg.Roles.EK)) {
            await button.clicker.member.roles.remove(cfg.Roles.EK)
            await button.think(true);
            await button.reply.edit(" Etkinlik Katılımcısı rolü üzerinizden alındı.")
        } else {
            await button.clicker.member.roles.add(cfg.Roles.EK)
            await button.think(true);
            await button.reply.edit("  Etkinlik Katılımcısı rolü üzerinize verildi.")
        }}

})



client.on('ready', async () => {

client.user.setPresence({ activity: { name: cfg.Bot.Durum }, status: cfg.Bot.Status })
let VoiceChannelID = client.channels.cache.get(cfg.Channels.VoiceChannelID)
if (VoiceChannelID) VoiceChannelID.join().catch(() => { })
console.log(`(${client.user.username}) adlı hesapta [${client.guilds.cache.get(cfg.Server.GuildID).name}] adlı sunucuda giriş yapıldı. ✔`)

});

client.login(cfg.Bot.Token).catch(() => console.error("Bota giriş yapılırken başarısız olundu!"));
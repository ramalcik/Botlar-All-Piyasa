const discord = require('discord.js');
const client = new discord.Client();
const disbut = require('discord-buttons')(client);
const cfg = require("./config.json");

client.on("message", async (msg) => {
let prefix = cfg.Bot.Prefix.find((x) => msg.content.toLowerCase().startsWith(x));
if (msg.content !== "-button" && msg.content !== "-buttons") return; 
if(!cfg.Bot.Owners.includes(msg.author.id) && !msg.guild.owner.user.id.includes(msg.author.id)) return

let dc = new disbut.MessageButton()
     .setStyle('red')
     .setLabel('Doğruluk & Cesaretlik')
     .setID('dc')
let vk = new disbut.MessageButton()
    .setStyle('gray')
    .setLabel('Vampir Köylü')
    .setID('vk')



msg.channel.send(`
Merhaba **Galaxy** üyeleri

 Aşağıda bulunan butonlardan Eğlence Rol Şeçme Menüsü Bulunmakta İstediğniz Gibi Şeçebilirsiniz
`, {
        buttons: [ dc , vk ]
    })

})
client.on('clickButton', async (button) => {

    if (button.id === 'dc') {
        if (button.clicker.member.roles.cache.get(cfg.Roles.dc)) {
            await button.clicker.member.roles.remove(cfg.Roles.dc)
            await button.think(true);
            await button.reply.edit(" Doğruluk & Cesaretlik rolü üzerinizden alındı.")
        } else {
            await button.clicker.member.roles.add(cfg.Roles.dc)
            await button.think(true);
            await button.reply.edit(" Doğruluk & Cesaretlik rolü üzerinize verildi.")
        }
    }
    if (button.id === 'vk') {
        if (button.clicker.member.roles.cache.get(cfg.Roles.vk)) {
            await button.clicker.member.roles.remove(cfg.Roles.vk)
            await button.think(true);
            await button.reply.edit(" Vampir Köylü rolü üzerinizden alındı.")
        } else {
            await button.clicker.member.roles.add(cfg.Roles.vk)
            await button.think(true);
            await button.reply.edit(" Vampir Köylü rolü üzerinize verildi.")
        }}

})



client.on('ready', async () => {

client.user.setPresence({ activity: { name: cfg.Bot.Durum }, status: cfg.Bot.Status })
let VoiceChannelID = client.channels.cache.get(cfg.Channels.VoiceChannelID)
if (VoiceChannelID) VoiceChannelID.join().catch(() => { })
console.log(`(${client.user.username}) adlı hesapta [${client.guilds.cache.get(cfg.Server.GuildID).name}] adlı sunucuda giriş yapıldı. ✔`)

});

client.login(cfg.Bot.Token).catch(() => console.error("Bota giriş yapılırken başarısız olundu!"));